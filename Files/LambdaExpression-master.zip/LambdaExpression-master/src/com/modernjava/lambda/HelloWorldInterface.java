package com.modernjava.lambda;

public interface HelloWorldInterface {
    //abstract method as it does not provide implementation
    public String sayHelloWorld();


}
